/**
 @file
 rezer~ - sampling/looping object by raja rez
 
 @ingroup    MSP
 */

#include "ext.h"
#include "ext_obex.h"
#include "ext_common.h" // contains CLAMP macro
#include "z_dsp.h"
#include "ext_buffer.h"

// Hermitic Cubic Interp ( courtesy of Alex Harker: http://www.alexanderjharker.co.uk/ )
#define HRMCBINTRP(f, z, a, b, c) ((((0.5*(c - z) + 1.5*(a - b))*f + (z - 2.5*a + b + b - 0.5*c))*f + (0.5*(b - z)))*f + a)

typedef struct _rezer {
    t_pxobject obj;
    t_buffer_ref *bf_ref;
    t_double sr;
    long nchan;
    long fad;
    long rfad;
    long xfad;
    long rxfad;
    long nend;
    long nstart;
    long nrend;
    long nrstart;
    t_bool playC;
    t_bool recC;
    t_bool wrap;
    t_bool rwrap;
    t_bool change;
    t_bool mode;
    t_double phprev;
    t_double rfprev;
    t_double speed;
    t_double fade;
    t_double pos;
    t_double xpos;
    t_double rpos;
    t_double rxpos;
    t_double vend;
    t_double vstart;
    t_double start;
    t_double end;
    t_double rstart;
    t_double rend;
} t_rezer;


void rezer_sperf64(t_rezer *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long vecfrmz, long flags, void *userparam);
void rezer_mperf64(t_rezer *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long vecfz, long flags, void *userparam);
void rezer_dsp64(t_rezer *x, t_object *dsp64, short *count, double samprate, long mxvecsize, long flgs);
void rezer_set(t_rezer *x, t_symbol *s);
void *rezer_new(t_symbol *s, long n);
void rezer_free(t_rezer *x);
void rezer_snoop(t_rezer *x, long n);
t_max_err rezer_notify(t_rezer *x, t_symbol *s, t_symbol *msg, void *sender, void *data);
void rezer_in1(t_rezer *x, long n);
void rezer_ph(t_rezer *x, t_double ph);
void rezer_rf(t_rezer *x, t_double rf);
void rezer_fade(t_rezer *x, t_double f);
void rezer_vend(t_rezer *x, t_double nd);
void rezer_vstart(t_rezer *x, t_double strt);
void rezer_assist(t_rezer *x, void *b, long m, long a, char *s);
void rezer_dblclick(t_rezer *x);
static t_class *rezer_class;
                                                              //easing function(fade/crossfade)
static inline double ease_func(double y1, char updwn, double ramp, long fad)
{
    return updwn ? y1*(0.5*(1.0-cos((1.0-(((double)fad)/ramp))*PI))) : y1*(0.5*(1.0-cos((((double)fad)/ramp)*PI)));
}

static inline void interp_index
(t_ptr_int p, t_ptr_int *ndx0,t_ptr_int *ndx1,t_ptr_int *ndx2,t_ptr_int *ndx3, t_double spd,t_ptr_int frms)
{
    t_ptr_int dr = (spd>=0)?1:-1;
    *ndx0 = p - dr; frms -= 1;                              //index-calc for cubic interpolation
    if(*ndx0 < 0) *ndx0 = frms + *ndx0; else if(*ndx0 > frms) *ndx0 = *ndx0 - frms;
    
    *ndx1 = p; *ndx2 = p + dr;
    if(*ndx2 < 0) *ndx2 = frms + *ndx2; else if(*ndx2 > frms) *ndx2 = *ndx2 - frms;
    
    *ndx3 = *ndx2 + dr;
    if(*ndx3 < 0) *ndx3 = frms + *ndx3; else if(*ndx3 > frms) *ndx3 = *ndx3 - frms;
    return;
}

static inline void regzger(t_ptr_int frm, long vecfz, t_double f, t_double dur,
                           t_double vstr, t_double vnd, t_ptr_int *nstr, t_ptr_int *nnd,
                           t_double *str, t_double *nd, t_bool *wr)
{              //registration and management of changes to playback/recording boundaries
    //....*str = 'virtual' start of the buffer(in frames); *nd = 'virtual' end of buffer(in frames);
    //....frm = total duration in 'frames' of the buffer~; vecfz = signal vector size('vector frames');
    //....f = starting phase input(0-1); dur = duration input(0-1);
    //....vstr = 'vstart' message(0-1 in terms of a virtual start point in buffer~'s overall length);
    //....vnd = 'vend' message(0-1 like 'vstart' but for a virtual end point);
    //....*nstr(nstart) = internal start time in frames, dependent on 4 things:
    //....................'virtual' start/end points('vstart' and 'vend' messages),
    //..............................and the incoming start 'phase' and 'duration' signal inputs
    //....*nnd(nend) = internal end time in frames, like *nstrt(nstart) mentioned above;
    //....*wr = wraparound flag(for when start/end makes play wrap around virtual bounds within buffer~)
    t_double vdur; f = (f<0) ? 0 : ((f>=0.999998)?0.999998:f);
    if(vstr<vnd){ *str=vstr*frm; *nd=vnd*frm; }
    else if(vstr>vnd){ *str=vnd*frm; *nd=vstr*frm; }else{ *str=0.; *nd=frm; };
    vdur = *nd - *str;
    if(dur>1.) dur=1.; else if(dur<0.) dur=0.; dur = dur * vdur; if(dur<vecfz) dur=vecfz;
    *nstr = (f*vdur) + *str;    *nnd = *nstr + dur;
    if(*nnd>=*nd) *nnd = *str + (*nnd-*nd); if(*nnd<=*str) *nnd = *nd - (*str-*nnd);
    if(*nnd<=*nstr) *wr=1; else *wr=0;                                       return;
}

void ext_main(void *r)
{
    t_class *c = class_new("rezer~", (method)rezer_new, (method)rezer_free, sizeof(t_rezer), 0L, A_SYM, A_DEFLONG, 0);
    
    class_addmethod(c, (method)rezer_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)rezer_set, "set", A_SYM, 0);
    class_addmethod(c, (method)rezer_in1, "in1", A_LONG, 0);
    class_addmethod(c, (method)rezer_ph, "ph", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_rf, "rf", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_fade, "fade", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_vend, "vend", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_vstart, "vstart", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_assist, "assist", A_CANT, 0);
    class_addmethod(c, (method)rezer_snoop, "snoop", A_NOTHING, 0);
    class_addmethod(c, (method)rezer_dblclick, "dblclick", A_CANT, 0);
    class_addmethod(c, (method)rezer_notify, "notify", A_CANT, 0);
    class_dspinit(c); class_register(CLASS_BOX, c); rezer_class = c;
}


void rezer_sperf64(t_rezer *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long vecfz, long flags, void *userparam)
{   //........inlets: starting 'phase', end, playControl, recordingControl, speed, recording-Inputs-L/R
    //........outlets: left-output, right-output (always stereo) ..phase-output
    t_double    *phase = ins[0];
    t_double    *dr = ins[1];
    t_double    *plyCtl = ins[2];
    t_double    *speed = ins[3];
    t_double    *rphase = ins[4];
    t_double    *rdr = ins[5];
    t_double    *rcCtl = ins[6];
    t_double    *rInL = ins[7];
    t_double    *rInR = ins[8];
    t_double    *outL = outs[0];
    t_double    *outR = outs[1];
    t_double    *outPh = outs[2];
    t_double    *outrPh = outs[3];
    t_bool      playC, recC, wrap, rwrap, change, mode;
    t_ptr_int   n = vecfz;
    t_ptr_int   chan, frames, nc, fad, xfad, rfad, rxfad, nend, nstart, nrend, nrstart;
    t_ptr_int   indx, indx0, indx1, indx2, indx3, xndx, xndx0, xndx1, xndx2, xndx3, rcdx, rxdx;
    t_float     *tab;
    t_double    f, rf, phprev, rfprev, frac, fric, playc, recc, fade, start, rstart, vstart;
    t_double    oL,oR,xL,xR,oP,rP, spd, dur, rdur, rcL, rcR, pos, xpos, rpos, rxpos, end, rend, vend;
    t_buffer_obj    *buffer = buffer_ref_getobject(x->bf_ref);
    
    tab = buffer_locksamples(buffer);  if (!tab) goto zero;
    frames = buffer_getframecount(buffer);
    nc = buffer_getchannelcount(buffer);
    mode = x->mode;
    chan = MIN(x->nchan, nc);
    start = x->start;
    end = x->end;
    rstart = x->rstart;
    rend = x->rend;
    vstart = x->vstart;
    vend = x->vend;
    if(!mode) change = x->change; else change = 1;
    pos = x->pos;
    xpos = x->xpos;
    rpos = x->rpos;
    rxpos = x->rxpos;
    playC = x->playC;
    recC = x->recC;
    wrap = x->wrap;
    rwrap = x->rwrap;
    fad = x->fad;
    xfad = x->xfad;
    rfad = x->rfad;
    rxfad = x->rxfad;
    phprev = x->phprev;
    rfprev = x->rfprev;
    nstart = x->nstart;
    nend = x->nend;
    nrstart = x->nrstart;
    nrend = x->nrend;
    spd = x->speed;
    fade = x->fade;
    //...........................................Perform Loop
    while (n--)
    {
        f=*phase++; dur=*dr++; playc=*plyCtl++; spd=*speed++;
        rf=*rphase++; rdur=*rdr++; recc=*rcCtl++; rcL=*rInL++; rcR=*rInR++;
        //....................................Starting/Stopping
        if (playc != playC)
        {
            if(xfad<0) //<-once on, crossfade(xfad) is priority
            {
                fad = fade;
                if (playc == 0) { playC=0; }
                else
                {
                    regzger(frames, vecfz, f, dur, vstart, vend, &nstart, &nend, &start, &end, &wrap);
                    if(spd>=0) pos = nstart; else pos = nend; playC = 1; change = 0;
                }
            }//..Once playing: 'phprev!=phas' detects phase change,..'xfad' = crossfade, 'fad' = fadein/out
        }   //............'change' = vstart/end registration(waits for loop-point/phase-change)
        if(playC)
        {
            if (((phprev != f) && (fad<0))&&(xfad<0))
            {
                if(!mode)
                {
                    regzger(frames, vecfz, f, dur, vstart, vend, &nstart, &nend, &start, &end, &wrap);
                    xpos = pos; if(spd>=0) pos = nstart; else pos = nend; xfad=fade; change = 0;
                }
            }else if(!wrap)
            {
                if (pos>nend)
                {
                    if(change)
                        regzger(frames,vecfz,f,dur,vstart,vend,&nstart,&nend,&start,&end,&wrap);
                    xpos=pos; pos = nstart; xfad=fade; change=0;
                }
                else if (pos<nstart)
                {
                    if(change)
                        regzger(frames,vecfz,f,dur,vstart,vend,&nstart,&nend,&start,&end,&wrap);
                    xpos=pos; pos = nend-1; xfad=fade; change=0;
                }
                if(pos>=end){ pos=start+(pos-end); }else if(pos<start){ pos=end-(start-pos); }
            }
            else
            {
                if ((pos>nend)&&(pos<nstart))
                {
                    if(change)
                        regzger(frames,vecfz,f,dur,vstart,vend,&nstart,&nend,&start,&end,&wrap);
                    xpos = pos; xfad=fade; change = 0; if(spd>=0) { pos = nstart; }else{ pos = nend-1; }
                }
                if(pos>=end){ pos=start+(pos-end); }else if(pos<start){ pos=end-(start-pos); }
            }
            
            indx = trunc(pos);
            if(spd>=0){ frac = pos-indx; }else if(spd<0){ frac = 1.0-(pos-indx); } else frac=0.0;
            interp_index(indx,&indx0,&indx1,&indx2,&indx3,spd,frames);
            xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
            xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
            pos += spd;
            
        //............................Crossfades(happen at loop-points and phase changes)
            if(xfad>=0)
            {
                xndx = trunc(xpos);
                if(spd>=0){ fric = xpos-xndx; }else if(spd<0){ fric = 1.0-(xpos-xndx); } else fric=0.0;
                interp_index(xndx,&xndx0,&xndx1,&xndx2,&xndx3,spd,frames);
                oL = HRMCBINTRP(fric, tab[xndx0*nc], tab[xndx1*nc], tab[xndx2*nc], tab[xndx3*nc]);
                oR = HRMCBINTRP(fric, tab[xndx0*nc+1], tab[xndx1*nc+1], tab[xndx2*nc+1], tab[xndx3*nc+1]);
                oL = ease_func(xL, 1, fade, xfad) + ease_func(oL, 0, fade, xfad);
                oR = ease_func(xR, 1, fade, xfad) + ease_func(oR, 0, fade, xfad);
                xpos += spd; xfad--; if(xpos>=frames) xpos -= frames; else if(xpos<0) xpos += frames;
            }
            else if(fad>=0)     //........................Fade-In
            { oL = ease_func(xL, 1, fade, fad); oR = ease_func(xR, 1, fade, fad); fad--; }
            else
            { oL = xL; oR = xR; } phprev = f;  //..<-Regular Playback + Phase-History
        }
        else
        {       //.......................................Fade-Out
            if(fad>=0)
            {
                indx = trunc(pos);
                if(spd>=0){ frac = pos-indx; }else if(spd<0){ frac = 1.0-(pos-indx); } else frac=0.0;
                interp_index(indx,&indx0,&indx1,&indx2,&indx3,spd,frames);
                xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
                xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
                pos += spd; if(pos>=frames) pos -= frames; else if(pos<0) pos += frames;
                oL = ease_func(xL, 0, fade, fad); oR = ease_func(xR, 0, fade, fad);     fad--;
            }else{ pos = oL = oR = 0.; }  //........<-Everything Off
        }
        oP = pos/(double)frames; //.......<-Sample-Index Converted to Phase
        //............................................................................................
        //..............................................RECORDING.....................................
        //............................................................................................
        if (recc != recC)
        {
            if(rxfad<0) //<-once on, crossfade(rxfad) is priority
            {
                rfad = fade;
                if(recc == 0){ recC=0; }
                else
                {
                    regzger(frames, vecfz*2, rf, rdur, 0., 1., &nrstart, &nrend, &rstart, &rend, &rwrap);
                    if(recc>=0) rpos = nrstart; else rpos = nrend; recC = 1;
                }
            }
        }   //..Once recording: 'rfprev!=rf' detects phase change,..'rxfad' = crossfade, 'rfad' = fadein/out
        if(recC)
        {
            if(!mode)
            {
                if (((rfprev != rf) && (rfad<0))&&(rxfad<0))
                {
                    regzger(frames, vecfz*2, rf, rdur, 0., 1., &nrstart, &nrend, &rstart, &rend, &rwrap);
                    rxpos = rpos; if(recc>=0) rpos = nrstart; else rpos = nrend; rxfad=fade;
                }
            }
            rcdx = trunc(rpos);     if(recc>=0) { rpos += 1; } else { rpos -= 1; }
            if(!rwrap)
            {
                if (rpos>nrend)
                {
                    regzger(frames,vecfz*2,rf,rdur,0.,1.,&nrstart,&nrend,&rstart,&rend,&rwrap);
                    rxpos=rpos; rpos = nrstart; rxfad=fade;
                }
                else if (rpos<nrstart)
                {
                    regzger(frames,vecfz*2,rf,rdur,0.,1.,&nrstart,&nrend,&rstart,&rend,&rwrap);
                    rxpos=rpos; rpos = nrend; rxfad=fade;
                }
                if(rpos>rend){ rpos=rstart+(rpos-rend); }else if(rpos<rstart){ rpos=rend-(rstart-rpos); }
            }
            else
            {
                if ((rpos>nrend)&&(rpos<nrstart))
                {
                    regzger(frames,vecfz*2,rf,rdur,0.,1.,&nrstart,&nrend,&rstart,&rend,&rwrap);
                    rxpos = rpos; rxfad=fade; if(recc>=0) { rpos = nrstart; }else{ rpos = nrend; }
                }
                if(rpos>rend){ rpos=rstart+(rpos-rend); }else if(rpos<rstart){ rpos=rend-(rstart-rpos); }
            }
            //............................Crossfades(happen at loop-points and phase changes)
            if(rxfad>=0)
            {
                rxdx = trunc(rxpos);
                tab[rxdx*nc] = ease_func(rcL, 0, fade, rxfad) + ease_func(tab[rxdx*nc], 1, fade, rxfad);
                tab[rxdx*nc+1] = ease_func(rcR, 0, fade, rxfad) + ease_func(tab[rxdx*nc+1], 1, fade, rxfad);
                tab[rcdx*nc] = ease_func(rcL, 1, fade, rxfad) + ease_func(tab[rcdx*nc], 0, fade, rxfad);
                tab[rcdx*nc+1] = ease_func(rcR, 1, fade, rxfad) + ease_func(tab[rcdx*nc+1], 0, fade, rxfad);
                if(recc>=0) { rxpos += 1; } else { rxpos -= 1; }
                if(rxpos>=frames) rxpos -= frames; else if(rxpos<0) rxpos += frames; rxfad--;
            }
            else if(rfad>=0)     //........................Fade-In
            {
                tab[rcdx*nc] = ease_func(rcL, 1, fade, rfad) + ease_func(tab[rcdx*nc], 0, fade, rfad);
                tab[rcdx*nc+1] = ease_func(rcR, 1, fade, rfad) + ease_func(tab[rcdx*nc+1], 0, fade, rfad);
                rfad--;
            }
            else
            { tab[rcdx*nc] = rcL; tab[rcdx*nc+1] = rcR; }; rfprev = rf;  //..<-RegularRec + Rec-Phase-History
        }
        else
        {       //.......................................Fade-Out
            if(rfad>=0)
            {
                rcdx = trunc(rpos);
                tab[rcdx*nc] = ease_func(rcL, 0, fade, rfad) + ease_func(tab[rcdx*nc], 1, fade, rfad);
                tab[rcdx*nc+1] = ease_func(rcR, 0, fade, rfad) + ease_func(tab[rcdx*nc+1], 1, fade, rfad);
                if(recc>=0) { rpos += 1; } else { rpos -= 1; }
                if(rpos>=frames) rpos -= frames; else if(rpos<0) rpos += frames;    rfad--;
            }
        }
        rP = rpos/(double)frames; //.......<-Sample-Index Converted to Phase
        
        *outL++ = oL; *outR++ = oR; *outPh++ = oP; *outrPh++ = rP;//.....<-Output
    }
    
    x->phprev = phprev;
    x->rfprev = rfprev;
    x->nend = nend;
    x->nstart = nstart;
    x->nrend = nrend;
    x->nrstart = nrstart;
    x->start = start;
    x->end = end;
    x->rstart = rstart;
    x->rend = rend;
    x->playC = playC;
    x->recC = recC;
    x->wrap = wrap;
    x->rwrap = rwrap;
    x->change = change;
    x->fad = fad;
    x->xfad = xfad;
    x->rfad = rfad;
    x->rxfad = rxfad;
    x->pos = pos;
    x->xpos = xpos;
    x->rpos = rpos;
    x->rxpos = rxpos;
    x->speed = spd;
    buffer_unlocksamples(buffer);
    return;
zero:
    while (n--) { *outL++ = 0.0; *outR++ = 0.0; *outPh++ = 0.0; *outrPh++ = 0.0; }
}

void rezer_set(t_rezer *x, t_symbol *s)
{
    t_buffer_obj    *buffer; t_double start, end, vs, ve; long frames;
    if (!x->bf_ref) x->bf_ref = buffer_ref_new((t_object *)x, s); else buffer_ref_set(x->bf_ref, s);
    buffer = buffer_ref_getobject(x->bf_ref); buffer_locksamples(buffer);
    frames = buffer_getframecount(buffer)-1; vs = x->vstart; ve = x->vend;
    if(vs<ve) { x->start = start = vs * frames; x->end = end = ve * frames; }
    else if(vs>ve){ x->start =  start = ve * frames; x->end = end = vs * frames; }
    else{ x->start= start = 0.; x->end = end = frames; };
    buffer_unlocksamples(buffer);
}

void rezer_in1(t_rezer *x, long n) { x->mode = n; post("rezer~ switching to mode: %ld", n); }

void rezer_ph(t_rezer *x, t_double ph){ ph = (ph>1) ? 1 : ph; ph = (ph<=0) ? 0 : ph; x->phprev=ph; }

void rezer_rf(t_rezer *x, t_double rf){ rf = (rf>1) ? 1 : rf; rf = (rf<=0) ? 0 : rf; x->rfprev=rf; }

void rezer_fade(t_rezer *x, t_double f){ x->fade = f; }

void rezer_vend(t_rezer *x, t_double nd)
{ nd = (nd > 1.) ? 1. : nd; nd = (nd <= 0.) ? 0.0002 : nd; x->vend = nd; x->change = 1; }

void rezer_vstart(t_rezer *x, t_double strt)
{ strt = (strt >= 1.) ? 0.9998 : strt; strt = (strt <= 0.) ? 0. : strt; x->vstart = strt; x->change = 1; }

void rezer_dsp64(t_rezer *x, t_object *dsp64, short *count, double samprate, long mxvecsize, long flgs)
{
    x->sr = samprate;
    if(x->nchan > 1) { dsp_add64(dsp64, (t_object *)x, (t_perfroutine64)rezer_sperf64, 0, NULL); }
    else{ dsp_add64(dsp64, (t_object *)x, (t_perfroutine64)rezer_mperf64, 0, NULL); }
    }

void rezer_dblclick(t_rezer *x) { buffer_view(buffer_ref_getobject(x->bf_ref)); }

void rezer_snoop(t_rezer *x, long n)
{
    post("nend: %ld", x->nend); post("nstart: %ld", x->nstart); post("nchan: %ld", x->nchan);
    post("wrap: %ld", x->wrap); post("change: %ld", x->change); post("fad: %ld", x->fad);
    post("xfad: %ld", x->xfad); post("start: %.3f", x->start); post("end: %.3f", x->end);
}
void rezer_assist(t_rezer *x, void *b, long m, long a, char *s)
{
    if (m == ASSIST_OUTLET) {switch (a)
        {
            case 0:    sprintf(s,"Left Out");    break;
            case 1:    if(x->nchan > 1) sprintf(s,"Right Out"); else sprintf(s,"Play Phase Out"); break;
            case 2:    if(x->nchan > 1) sprintf(s,"Play Phase Out"); else sprintf(s,"Rec Phase Out"); break;
            case 3:    sprintf(s, "Rec Phase Out"); break;
        }       }
    else {switch (a)
        {
            case 0:    sprintf(s,"(signal) Starting Phase/Index (+ other messages)..."); break;
            case 1:    sprintf(s,"Duration Of Loop Window");    break;
            case 2:    sprintf(s,"Play Control");    break;
            case 3:    sprintf(s,"Speed");    break;
            case 4:    sprintf(s,"Starting Recording-Phase/Index");    break;
            case 5:    sprintf(s,"Duration Of Recording Loop Window");    break;
            case 6:    sprintf(s,"Recording Control");    break;
            case 7:    sprintf(s,"Recording Input Left");    break;
            case 8:    sprintf(s,"Recording Input Right");    break;
        }       }
}

void *rezer_new(t_symbol *s, long n)
{
    long chan = 2; if(n) chan = n;
    t_rezer *x = object_alloc(rezer_class); dsp_setup((t_pxobject *)x, 9);
    if(chan>1)
    {
        outlet_new((t_object *)x,"signal"); outlet_new((t_object *)x,"signal");
        outlet_new((t_object *)x,"signal"); outlet_new((t_object *)x,"signal");
    }
    else
    {
        outlet_new((t_object *)x,"signal"); outlet_new((t_object *)x,"signal");
        outlet_new((t_object *)x,"signal");
    }
    rezer_set(x, s); x->nchan = chan; x->mode = x->wrap = x->rwrap = x->playC = x->recC = 0;
    x->fade = 512.; x->change = x->phprev = x->rfprev = x->vstart = x->pos = x->xpos = x->rpos = x->rxpos = 0.;
    x->fad = x->xfad = x->rfad = x->rxfad= -1; x->vend = x->speed = 1.;
    post("rezer~ v.006 - mode %ld", x->mode);   return (x);
}

void rezer_free(t_rezer *x) { dsp_free((t_pxobject *)x); object_free(x->bf_ref); }

t_max_err rezer_notify(t_rezer *x, t_symbol *s, t_symbol *msg, void *sender, void *data)
{ return buffer_ref_notify(x->bf_ref, s, msg, sender, data); }

/*_____________________________MONO PERF LOOP_______________________________________*/

void rezer_mperf64(t_rezer *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long vecfz, long flags, void *userparam)
{   //........inlets: starting 'phase', end, playControl, recordingControl, speed, recording-Inputs-L/R
    //........outlets: left-output, right-output (always stereo) ..phase-output
    t_double    *phase = ins[0];
    t_double    *dr = ins[1];
    t_double    *plyCtl = ins[2];
    t_double    *rcCtl = ins[3];
    t_double    *speed = ins[4];
    t_double    *rInL = ins[5];
    t_double    *outL = outs[0];
    t_double    *outPh = outs[1];
    t_bool      playC, wrap, change, mode;
    t_ptr_int   n = vecfz;
    t_ptr_int   chan, frames, nc, fad, xfad, nend, nstart;
    t_ptr_int   indx, indx0, indx1, indx2, indx3, xndx, xndx0, xndx1, xndx2, xndx3;
    t_float     *tab;
    t_double    f, phprev, frac, fric, playc, recc, fade, start, vstart;
    t_double    oL,xL,oP, spd, dur, rcL, pos, xpos, end, vend;
    t_buffer_obj    *buffer = buffer_ref_getobject(x->bf_ref);
    
    tab = buffer_locksamples(buffer);  if (!tab) goto zero;
    frames = buffer_getframecount(buffer);
    nc = buffer_getchannelcount(buffer);
    mode = x->mode;
    chan = MIN(x->nchan, nc);
    start = x->start;
    end = x->end;
    vstart = x->vstart;
    vend = x->vend;
    if(!mode) change = x->change; else change = 1;
    pos = x->pos;
    xpos = x->xpos;
    playC = x->playC;
    wrap = x->wrap;
    fad = x->fad;
    xfad = x->xfad;
    phprev = x->phprev;
    nstart = x->nstart;
    nend = x->nend;
    spd = x->speed;
    fade = x->fade;
    //...........................................Perform Loop
    while (n--)
    {
        f=*phase++; dur=*dr++; playc=*plyCtl++; recc=*rcCtl++; spd=*speed++; rcL=*rInL++;
        //....................................Starting/Stopping
        if (playc != playC)
        {
            if(xfad<0) //<-once on, crossfade(xfad) is priority
            {
                fad = fade;
                if (playc == 0) { playC=0; }
                else
                {
                    regzger(frames, vecfz, f, dur, vstart, vend, &nstart, &nend, &start, &end, &wrap);
                    if(spd>=0) pos = nstart; else pos = nend; playC = 1; change = 0;
                }
            }//..Once playing: 'phprev!=phas' detects phase change,..'xfad' = crossfade, 'fad' = fadein/out
        }   //............'change' = vstart/end registration(waits for loop-point/phase-change)
        if(playC)
        {
            if(!mode)
            {
                if (((phprev != f) && (fad<0))&&(xfad<0))
                {
                    regzger(frames, vecfz, f, dur, vstart, vend, &nstart, &nend, &start, &end, &wrap);
                    xpos = pos; if(spd>=0) pos = nstart; else pos = nend; xfad=fade; change = 0;
                }
            }
            
            indx = trunc(pos);
            if(spd>=0){ frac = pos-indx; }else if(spd<0){ frac = 1.0-(pos-indx); } else frac=0.0;
            interp_index(indx,&indx0,&indx1,&indx2,&indx3,spd,frames);
            xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
            pos += spd;
            if(!wrap)
            {
                if (pos>nend)
                {
                    if(change)
                        regzger(frames,vecfz,f,dur,vstart,vend,&nstart,&nend,&start,&end,&wrap);
                    xpos=pos; pos = nstart; xfad=fade; change=0;
                }
                else if (pos<nstart)
                {
                    if(change)
                        regzger(frames,vecfz,f,dur,vstart,vend,&nstart,&nend,&start,&end,&wrap);
                    xpos=pos; pos = nend; xfad=fade; change=0;
                }
                if(pos>end){ pos=start+(pos-end); }else if(pos<start){ pos=end-(start-pos); }
            }
            else
            {
                if ((pos>nend)&&(pos<nstart))
                {
                    if(change)
                        regzger(frames,vecfz,f,dur,vstart,vend,&nstart,&nend,&start,&end,&wrap);
                    xpos = pos; xfad=fade; change = 0;
                    if(spd>=0) { pos = nstart; }else{ pos = nend; }
                }
                if(pos>end){ pos=start+(pos-end); }else if(pos<start){ pos=end-(start-pos); }
            }
            //............................Crossfades(happen at loop-points and phase changes)
            if(xfad>=0)
            {
                xndx = trunc(xpos);
                if(spd>=0){ fric = xpos-xndx; }else if(spd<0){ fric = 1.0-(xpos-xndx); } else fric=0.0;
                interp_index(xndx,&xndx0,&xndx1,&xndx2,&xndx3,spd,frames);
                oL = HRMCBINTRP(fric, tab[xndx0*nc], tab[xndx1*nc], tab[xndx2*nc], tab[xndx3*nc]);
                oL = ease_func(xL, 1, fade, xfad) + ease_func(oL, 0, fade, xfad);
                xpos += spd; xfad--; if(xpos>=frames) xpos -= frames; else if(xpos<0) xpos += frames;
            }
            else if(fad>=0)     //........................Fade-In
            { oL = ease_func(xL, 1, fade, fad); fad--; }
            else oL = xL;               phprev = f;             //..<-Regular Playback + Phase-History
        }
        else
        {       //.......................................Fade-Out
            if(fad>=0)
            {
                indx = trunc(pos);
                if(spd>=0){ frac = pos-indx; }else if(spd<0){ frac = 1.0-(pos-indx); } else frac=0.0;
                interp_index(indx,&indx0,&indx1,&indx2,&indx3,spd,frames);
                xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
                pos += spd; if(pos>=frames) pos -= frames; else if(pos<0) pos += frames;
                oL = ease_func(xL, 0, fade, fad);     fad--;
            }else{ pos = oL = 0.; }  //........<-Everything Off
        }
        oP = pos/(double)frames; //.......<-Sample-Index Converted to Phase
        *outL++ = oL; *outPh++ = oP; //.....<-Output
    }
    
    x->phprev = phprev;
    x->nend = nend;
    x->nstart = nstart;
    x->start = start;
    x->end = end;
    x->playC = playC;
    x->wrap = wrap;
    x->change = change;
    x->fad = fad;
    x->xfad = xfad;
    x->pos = pos;
    x->xpos = xpos;
    x->speed = spd;
    buffer_unlocksamples(buffer);
    return;
zero:
    while (n--) { *outL++ = 0.0; *outPh++ = 0.0; }
}
