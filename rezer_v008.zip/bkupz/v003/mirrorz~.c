/**
 @file
 mirrorz~ - sampling/looping object by raja
 
 @ingroup    MSP
 */

#include "ext.h"
#include "ext_obex.h"
#include "ext_common.h" // contains CLAMP macro
#include "z_dsp.h"
#include "ext_buffer.h"

// Hermitic Cubic Interp ( courtesy of Alex Harker: http://www.alexanderjharker.co.uk/ )
#define HRMCBINTRP(f, z, a, b, c) ((((0.5*(c - z) + 1.5*(a - b))*f + (z - 2.5*a + b + b - 0.5*c))*f + (0.5*(b - z)))*f + a)

typedef struct _mirrorz {
    t_pxobject obj;
    t_buffer_ref *bf_ref;
    t_double sr;
    long nchan;
    long loopfad;
    long ntrnl_mm_bytelen;
    t_bool playC;
    t_double *ntrnl_mmL;
    t_double *ntrnl_mmR;
    t_double *play_headL;
    t_double *play_headR;
    t_double *read_headL;
    t_double *read_headR;
    t_double phprev;
    t_double end;
    t_double speed;
    t_ptr_int aeropos;
    t_ptr_int hyropos;
} t_mirrorz;


void mirrorz_perform64(t_mirrorz *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampfrms, long flags, void *userparam);
void mirrorz_dsp64(t_mirrorz *x, t_object *dsp64, short *count, double samprate, long mxvecsize, long flgs);
void mirrorz_set(t_mirrorz *x, t_symbol *s);
void *mirrorz_new(t_symbol *s);
void mirrorz_free(t_mirrorz *x);
t_max_err mirrorz_notify(t_mirrorz *x, t_symbol *s, t_symbol *msg, void *sender, void *data);
void mirrorz_in1(t_mirrorz *x, long n);
void mirrorz_assist(t_mirrorz *x, void *b, long m, long a, char *s);
void mirrorz_dblclick(t_mirrorz *x);


static t_class *mirrorz_class;
static inline double ease_func(double y1, char updwn, double ramp, long fad)
{ return updwn ? y1*(0.5*(1.0-cos((1.0-(((double)fad)/ramp))*PI))) : y1*(0.5*(1.0-cos((((double)fad)/ramp)*PI))); }

static inline void interp_index
(t_ptr_int pos,
 t_ptr_int *indx0,t_ptr_int *indx1,t_ptr_int *indx2,t_ptr_int *indx3,
 t_ptr_int dir,t_ptr_int frames)
{
    *indx0 = pos - dir; frames -= 1;                                //calc of indexes 4 interps
    if(*indx0 < 0) *indx0 = frames + *indx0; else if(*indx0 > frames) *indx0 = *indx0 - frames;
    
    *indx1 = pos; *indx2 = pos + dir;
    if(*indx2 < 0) *indx2 = frames + *indx2; else if(*indx2 > frames) *indx2 = *indx2 - frames;
    
    *indx3 = *indx2 + dir;
    if(*indx3 < 0) *indx3 = frames + *indx3; else if(*indx3 > frames) *indx3 = *indx3 - frames;
    return;
}

void ext_main(void *r)
{
    t_class *c = class_new("mirrorz~", (method)mirrorz_new, (method)mirrorz_free, sizeof(t_mirrorz), 0L, A_SYM, A_DEFLONG, 0);
    
    class_addmethod(c, (method)mirrorz_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)mirrorz_set, "set", A_SYM, 0);
    class_addmethod(c, (method)mirrorz_in1, "in1", A_LONG, 0);
    class_addmethod(c, (method)mirrorz_assist, "assist", A_CANT, 0);
    class_addmethod(c, (method)mirrorz_dblclick, "dblclick", A_CANT, 0);
    class_addmethod(c, (method)mirrorz_notify, "notify", A_CANT, 0);
    class_dspinit(c);
    class_register(CLASS_BOX, c);
    mirrorz_class = c;
}


void mirrorz_perform64(t_mirrorz *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampfrms, long flags, void *userparam)
{
    t_double    *phase = ins[0];
    t_double    *end = ins[1];
    t_double    *playCtrl = ins[2];
    t_double    *recCtrl = ins[3];
    t_double    *speed = ins[4];
    t_double    *recInL = ins[5];
    t_double    *recInR = ins[6];
    t_double    *outL = outs[0];
    t_double    *outR = outs[1];
    t_double    *outPh = outs[2];
    t_bool      playC, loopover;
    t_ptr_int   n = sampfrms;
    t_ptr_int   bi, chan, frames, nc, aeropos, hyropos, fadout, loopfad;
    t_ptr_int   indx, indx0, indx1, indx2, indx3, jndx, jndx0, jndx1, jndx2, jndx3, dir;
    t_float     *tab;
    t_double    phas, phprev, f, g, frac, fric, playc, recc, spd, oL, oR, xL, xR, oP, nend, nd, rcL, rcR;
    t_double    *ntrnl_mmL = x->ntrnl_mmL;
    t_double    *ntrnl_mmR = x->ntrnl_mmR;
    t_double    *playL = x->play_headL;
    t_double    *playR = x->play_headR;
    t_double    *readL = x->read_headL;
    t_double    *readR = x->read_headR;
    t_double    *trackL;
    t_double    *trackR;
    
    t_buffer_obj    *buffer = buffer_ref_getobject(x->bf_ref);
    
    tab = buffer_locksamples(buffer);
    if (!tab) goto zero;
    
    frames = buffer_getframecount(buffer);
    nc = buffer_getchannelcount(buffer);
    chan = MIN(x->nchan, nc);
    aeropos = x->aeropos;
    playC = x->playC;
    loopfad = x->loopfad;
    phprev = x->phprev;
    nend = x->end;
    spd = x->speed;
    if (spd>=0) dir = 1; else dir = -1; fadout = 0;
    
    if(playC)
    {
        readL = ntrnl_mmL; readR = ntrnl_mmR;
        for (bi=0;bi<=sampfrms;bi++)
        {
            g = aeropos + (bi * spd);
            if(dir>0) { indx = g+0.5; frac = g - indx; } else { indx = g-0.5; frac = indx - g; }
            if(!loopfad)
            {
                if((indx<(phprev*frames))||(indx>nend))
                { loopfad = 64; if(dir>0) hyropos = (phprev*frames); else hyropos = nend; }
                oL = 0.; oR = 0.;
            }
            if (indx<0) indx += frames; else if (indx>=frames) indx -= frames;
            interp_index(indx,&indx0,&indx1,&indx2,&indx3,dir,frames);
            xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
            xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
            if(loopfad)
            {
                f = hyropos + (bi * spd);
                if(dir>0) { jndx = f+0.5; fric = f - jndx; } else { jndx = f-0.5; fric = jndx - f; }
                if (jndx<0) jndx += frames; else if (jndx>=frames) jndx -= frames;
                interp_index(jndx,&jndx0,&jndx1,&jndx2,&jndx3,dir,frames);
                oL = HRMCBINTRP(fric, tab[jndx0*nc], tab[jndx1*nc], tab[jndx2*nc], tab[jndx3*nc]);
                oR = HRMCBINTRP(fric, tab[jndx0*nc+1], tab[jndx1*nc+1], tab[jndx2*nc+1], tab[jndx3*nc+1]);
                oL = ease_func(oL, 0, 64., loopfad); oR = ease_func(oR, 0, 64., loopfad);
                xL = ease_func(xL, 1, 64., loopfad); xR = ease_func(xR, 1, 64., loopfad);
                loopfad--; if(!loopfad) aeropos = hyropos;
            }
            *readL++ = xL + oL;  *readR++ = xR + oR;
        }
        playL = ntrnl_mmL; playR = ntrnl_mmR;    aeropos += (sampfrms*spd+(dir*0.5));
        if(loopfad)
        {
            hyropos += (sampfrms*spd+(dir*0.5));
            if (hyropos>=nend){ hyropos = (phprev*frames) + (hyropos-nend); loopover=1; }
            else if(hyropos<(phprev*frames)){ hyropos = nend - ((phprev*frames) - hyropos); loopover=1; }
        }
        if (aeropos>=nend){ aeropos = (phprev*frames) + (aeropos-nend); loopover=1; }
        else if(aeropos<(phprev*frames)){ aeropos = nend - ((phprev*frames) - aeropos); loopover=1; }
    }
    
    while (n--)
    {
        phas = *phase++; nd = *end++; playc = *playCtrl++; recc = *recCtrl++; spd = *speed++;
        rcL = *recInL++; rcR = *recInR++; nd *= frames;
        if(nd<=0.) nd = sampfrms+2; else if(nd>=frames) nd=frames-1;
        f = phas * frames; if (spd>=0) dir = 1; else dir = -1;
        if ((phprev!=phas)&&(n>(sampfrms*0.125)))
        {
            trackL = readL = playL; trackR = readR = playR; nend = nd;
            for (bi=0;bi<=n;bi++)
            {
                g = f + (bi * spd);
                if(dir>0) { indx = g+0.5; frac = g - indx; } else { indx = g-0.5; frac = indx - g; }
                if (indx<0) indx += frames; else if (indx>=frames) indx -= frames;
                interp_index(indx,&indx0,&indx1,&indx2,&indx3,dir,frames);
                xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
                xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
                *readL++ = ease_func(xL, 0, n, bi) + ease_func(*playL++, 1, n, bi);
                *readR++ = ease_func(xR, 0, n, bi) + ease_func(*playR++, 1, n, bi);
            }
            playL = trackL; playR = trackR;     aeropos = (f+(dir*0.5)) + (n*spd);
            if (aeropos>=nend) aeropos = (f+(dir*0.5)) + (aeropos - nend);
            else if (aeropos<(f+(dir*0.5))) aeropos = nend - ((f+(dir*0.5)) - aeropos);
        }
        if ((playc!=playC)&&(n>(sampfrms*0.125)))
        {
            fadout = n;
            if (playc == 0) { playC=0; }
            else
            {
                readL = ntrnl_mmL; readR = ntrnl_mmR; nend = nd;
                for (bi=0;bi<=n;bi++)
                {
                    g = f + (bi * spd);
                    if(dir>0) { indx = g+0.5; frac = g - indx; } else { indx = g-0.5; frac = indx - g; }
                    if (indx<0) indx += frames; else if (indx>=frames) indx -= frames;
                    interp_index(indx,&indx0,&indx1,&indx2,&indx3,dir,frames);
                    xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
                    xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
                    *readL++ = ease_func(xL, 0, n, bi); *readR++ = ease_func(xR, 0, n, bi);
                }
                playL = ntrnl_mmL; playR = ntrnl_mmR;  aeropos = (f+(dir*0.5)) + (n*spd);  playC = 1;
                if (aeropos>=nend) aeropos = (f+(dir*0.5)) + (aeropos - nend);
                else if (aeropos<(f+(dir*0.5))) aeropos = nend - ((f+(dir*0.5)) - aeropos);
            }
        }
        
                                /*__________Output__________*/
        
        if(playC>0) { oL = *playL++; oR = *playR++; }
        else
        {
            if(!fadout) { oL=0.; oR=0.; }
            else { oL=ease_func(*playL++,0,fadout,n); oR=ease_func(*playR++,0,fadout,n); if(n==1)fadout=0; }
        }
        
        oP = (aeropos + ((sampfrms - n)*spd))/(double)frames;
        if (oP>=frames) oP -= frames; else if (oP<0) oP += frames;
        *outL++ = oL; *outR++ = oR; *outPh++ = oP; phprev = phas;
    }
    
    x->phprev = phprev;
    x->end = nend;
    x->playC = playC;
    x->loopfad = loopfad;
    x->aeropos = aeropos;
    x->hyropos = hyropos;
    x->speed = spd;
    x->play_headL = playL;
    x->play_headR = playR;
    x->read_headL = readL;
    x->read_headR = readR;
    buffer_unlocksamples(buffer);
    return;
zero:
    while (n--) *outL++ = 0.0;
}

void mirrorz_set(t_mirrorz *x, t_symbol *s)
{
    t_buffer_obj    *buffer;
    if (!x->bf_ref) x->bf_ref = buffer_ref_new((t_object *)x, s); else buffer_ref_set(x->bf_ref, s);
    buffer = buffer_ref_getobject(x->bf_ref); buffer_locksamples(buffer);
    x->end = buffer_getframecount(buffer); buffer_unlocksamples(buffer);
}

void mirrorz_in1(t_mirrorz *x, long n) { if (n) x->nchan = MAX(n, 2) - 1; else x->nchan = 1; }

void mirrorz_dsp64(t_mirrorz *x, t_object *dsp64, short *count, double samprate, long mxvecsize, long flgs)
{
    x->sr = samprate; x->ntrnl_mm_bytelen = (mxvecsize * 2) * sizeof(double);
    if (x->ntrnl_mmL == NULL) { x->ntrnl_mmL = (double *) sysmem_newptrclear(x->ntrnl_mm_bytelen); }
    else { x->ntrnl_mmL = (double *) sysmem_resizeptrclear(x->ntrnl_mmL, x->ntrnl_mm_bytelen); }
    if (x->ntrnl_mmL == NULL) { error("mirrorz~: cannot allocate internal memory"); return; }
    x->play_headL = x->ntrnl_mmL;
    if (x->ntrnl_mmR == NULL) { x->ntrnl_mmR = (double *) sysmem_newptrclear(x->ntrnl_mm_bytelen); }
    else { x->ntrnl_mmR = (double *) sysmem_resizeptrclear(x->ntrnl_mmR, x->ntrnl_mm_bytelen); }
    if (x->ntrnl_mmR == NULL) { error("mirrorz~: cannot allocate internal memory"); return; }
    x->play_headR = x->ntrnl_mmR;
    dsp_add64(dsp64, (t_object *)x, (t_perfroutine64)mirrorz_perform64, 0, NULL);
}

void mirrorz_dblclick(t_mirrorz *x) { buffer_view(buffer_ref_getobject(x->bf_ref)); }

void mirrorz_assist(t_mirrorz *x, void *b, long m, long a, char *s)
{
    if (m == ASSIST_OUTLET) {switch (a)
        {
            case 0:    sprintf(s,"Left Out");    break;
            case 1:    sprintf(s,"Right Out");    break;
            case 2:    sprintf(s,"Phase Out");    break;
        }
    }
    else {switch (a)
        {
            case 0:    sprintf(s,"(signal) Phase/Index Input (other)...");    break;
            case 1:    sprintf(s,"Ending Phase");    break;
            case 2:    sprintf(s,"Play Control");    break;
            case 3:    sprintf(s,"Recording Control");    break;
            case 4:    sprintf(s,"Speed");    break;
            case 5:    sprintf(s,"Recording Input Left");    break;
            case 6:    sprintf(s,"Recording Input Right");    break;
        }
    }
}

void *mirrorz_new(t_symbol *s)
{
    long chan = 2; t_mirrorz *x = object_alloc(mirrorz_class); dsp_setup((t_pxobject *)x, 7);
    outlet_new((t_object *)x, "signal"); outlet_new((t_object *)x, "signal");
    outlet_new((t_object *)x, "signal"); mirrorz_set(x, s); mirrorz_in1(x,chan);
    x->loopfad = x->playC = x->aeropos = x->hyropos = 0;
    x->speed = 1.; x->phprev = 0.; x->obj.z_misc |= Z_NO_INPLACE; post("v.003"); return (x);
}

void mirrorz_free(t_mirrorz *x) { dsp_free((t_pxobject *)x); object_free(x->bf_ref); }

t_max_err mirrorz_notify(t_mirrorz *x, t_symbol *s, t_symbol *msg, void *sender, void *data)
{ return buffer_ref_notify(x->bf_ref, s, msg, sender, data); }
