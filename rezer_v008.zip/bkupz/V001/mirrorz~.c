/**
 @file
 mirrorz~ - sampling/looping object by raja
 
 @ingroup    MSP
 */

#include "ext.h"
#include "ext_obex.h"
#include "ext_common.h" // contains CLAMP macro
#include "z_dsp.h"
#include "ext_buffer.h"


typedef struct _mirrorz {
    t_pxobject obj;
    t_buffer_ref *l_buffer_reference;
    double sr;
    long nchan;
    long ntrnl_mm_bytelen;
    long playC;
    double *ntrnl_mmL;
    double *ntrnl_mmR;
    double *play_headL;
    double *play_headR;
    double *read_headL;
    double *read_headR;
    double phprev;
    long bufvec_pos;
} t_mirrorz;


void mirrorz_perform64(t_mirrorz *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
void mirrorz_dsp64(t_mirrorz *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags);
void mirrorz_set(t_mirrorz *x, t_symbol *s);
void *mirrorz_new(t_symbol *s);
void mirrorz_free(t_mirrorz *x);
t_max_err mirrorz_notify(t_mirrorz *x, t_symbol *s, t_symbol *msg, void *sender, void *data);
void mirrorz_in1(t_mirrorz *x, long n);
void mirrorz_assist(t_mirrorz *x, void *b, long m, long a, char *s);
void mirrorz_dblclick(t_mirrorz *x);


static t_class *mirrorz_class;
static inline double ease_func(double y1, char updwn, double ramp, long fad)
{ return updwn ? y1*(0.5*(1.0-cos((1.0-(((double)fad)/ramp))*PI))) : y1*(0.5*(1.0-cos((((double)fad)/ramp)*PI))); }

static inline double eqpfade(double y1, char updwn, double rmp, long fad)
{ return updwn ? y1 * pow(( 0.5 + 0.5*cos(PI*((double)fad/rmp)) ),.5) :
    y1 * pow(( 0.5 - 0.5*cos(PI*((double)fad/rmp)) ),.5); }

void ext_main(void *r)
{
    t_class *c = class_new("mirrorz~", (method)mirrorz_new, (method)mirrorz_free, sizeof(t_mirrorz), 0L, A_SYM, A_DEFLONG, 0);
    
    class_addmethod(c, (method)mirrorz_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)mirrorz_set, "set", A_SYM, 0);
    class_addmethod(c, (method)mirrorz_in1, "in1", A_LONG, 0);
    class_addmethod(c, (method)mirrorz_assist, "assist", A_CANT, 0);
    class_addmethod(c, (method)mirrorz_dblclick, "dblclick", A_CANT, 0);
    class_addmethod(c, (method)mirrorz_notify, "notify", A_CANT, 0);
    class_dspinit(c);
    class_register(CLASS_BOX, c);
    mirrorz_class = c;
}


void mirrorz_perform64(t_mirrorz *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
    t_double    *phase = ins[0];
    t_double    *recInL = ins[1];
    t_double    *recInR = ins[2];
    t_double    *playCtrl = ins[3];
    t_double    *recCtrl = ins[4];
    t_double    *speed = ins[5];
    t_double    *outL = outs[0];
    t_double    *outR = outs[1];
    t_double    *outPh = outs[2];
    
    int            n = sampleframes;
    int             index;
    long        bi, chan, frames, nc, bufvecpos, playC, tmp, fadeout;
    t_float        *tab;
    double        temp, phprev, f, playc, recc, spd, oL, oR, oP, test;
    double        *ntrnl_mmL = x->ntrnl_mmL;
    double        *ntrnl_mmR = x->ntrnl_mmR;
    double        *playL = x->play_headL;
    double        *playR = x->play_headR;
    double        *readL = x->read_headL;
    double        *readR = x->read_headR;
    double        *trackL;
    double        *trackR;
    
    t_buffer_obj    *buffer = buffer_ref_getobject(x->l_buffer_reference);
    
    tab = buffer_locksamples(buffer);
    if (!tab)
        goto zero;
    
    frames = buffer_getframecount(buffer);
    nc = buffer_getchannelcount(buffer);
    chan = MIN(x->nchan, nc);
    bufvecpos = x->bufvec_pos;
    playC = x->playC;
    phprev = x->phprev;
    
    if(playC)
    {
        readL = ntrnl_mmL;
        readR = ntrnl_mmR;
        for (bi=0;bi<sampleframes;bi++)
        {
            tmp = bufvecpos+bi;
            if (tmp<0) tmp += frames;
            else if (tmp>=frames) tmp -= frames;
            *readL++ = tab[tmp*nc];
            *readR++ = tab[tmp*nc+1];
        }
        playL = ntrnl_mmL;
        playR = ntrnl_mmR;
        bufvecpos += sampleframes;
        if (bufvecpos>=frames) bufvecpos -= frames;
    }
    tmp = fadeout = 0;
    
    while (n--)
    {
        temp = *phase++; playc = *playCtrl++; recc = *recCtrl++; spd = *speed++;
        f = temp * frames; index = f;
        if ((phprev!=temp)&&(n>(sampleframes*0.125)))
        {
            trackL = readL = playL;
            trackR = readR = playR;
            for (bi=0;bi<=n;bi++)
            {
                tmp = index + bi;
                if (tmp<0) tmp += frames;
                else if (tmp>=frames) tmp -= frames;
                *readL++ =
                    eqpfade((double)tab[tmp*nc], 0, n, bi) + eqpfade(*playL++, 1, n, bi);
                *readR++ =
                    eqpfade((double)tab[tmp*nc+1], 0, n, bi) + eqpfade(*playR++, 1, n, bi);
            }
            playL = trackL;
            playR = trackR;
            bufvecpos = f + n;
            if (bufvecpos>=frames) bufvecpos -= frames;
        }
        if ((playc!=playC)&&(n>(sampleframes*0.125)))
        {
            if (playc == 0)
            {
                playC = 0; fadeout = n;
            }
            else
            {
                readL = ntrnl_mmL;
                readR = ntrnl_mmR;
                for (bi=0;bi<=n;bi++)
                {
                    tmp = index + bi;
                    if (tmp>=frames) tmp -= frames;
                    *readL++ = tab[tmp*nc];
                    *readR++ = tab[tmp*nc+1];
                }
                playL = ntrnl_mmL;
                playR = ntrnl_mmR;
                bufvecpos = f + n;
                if (bufvecpos>=frames) bufvecpos -= frames;
                playC = 1; fadeout = n;
            }
        }
        if(playC>0)
        {
            if(fadeout)
            {
                oL = ease_func(*playL++, 1, fadeout, n);
                oR = ease_func(*playR++, 1, fadeout, n);
                if (n==1) fadeout=0;
            }
            else
            { oL = *playL++; oR = *playR++; }
        }
        else
        {
            if(fadeout)
            {
                oL = ease_func(*playL++, 0, fadeout, n);
                oR = ease_func(*playR++, 0, fadeout, n);
                if (n==1) fadeout=0;
            }
            else
            { oL = 0.; oR = 0.; }
        }
        oP = (bufvecpos + (sampleframes - n))/(double)frames;
        *outL++ = oL; *outR++ = oR; *outPh++ = oP;
        phprev = temp;
    }
    x->phprev = phprev;
    x->playC = playC;
    x->bufvec_pos = bufvecpos;
    x->play_headL = playL;
    x->play_headR = playR;
    x->read_headL = readL;
    x->read_headR = readR;
    buffer_unlocksamples(buffer);
    return;
zero:
    while (n--)
        *outL++ = 0.0;
}

void mirrorz_set(t_mirrorz *x, t_symbol *s)
{
    if (!x->l_buffer_reference)
        x->l_buffer_reference = buffer_ref_new((t_object *)x, s);
    else
        buffer_ref_set(x->l_buffer_reference, s);
}

void mirrorz_in1(t_mirrorz *x, long n)
{
    if (n)
        x->nchan = MAX(n, 2) - 1;
    else
        x->nchan = 1;
}


void mirrorz_dsp64(t_mirrorz *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags)
{
    x->sr = samplerate;
    x->ntrnl_mm_bytelen = (maxvectorsize * 2) * sizeof(double);
    if (x->ntrnl_mmL == NULL)
    {
        x->ntrnl_mmL = (double *) sysmem_newptrclear(x->ntrnl_mm_bytelen);
    }
    else
    {
        x->ntrnl_mmL = (double *) sysmem_resizeptrclear(x->ntrnl_mmL, x->ntrnl_mm_bytelen);
    }
    if (x->ntrnl_mmL == NULL) { error("mirrorz~: cannot allocate internal memory"); return; }
    x->play_headL = x->ntrnl_mmL;
    if (x->ntrnl_mmR == NULL)
    {
        x->ntrnl_mmR = (double *) sysmem_newptrclear(x->ntrnl_mm_bytelen);
    }
    else
    {
        x->ntrnl_mmR = (double *) sysmem_resizeptrclear(x->ntrnl_mmR, x->ntrnl_mm_bytelen);
    }
    if (x->ntrnl_mmR == NULL) { error("mirrorz~: cannot allocate internal memory"); return; }
    x->play_headR = x->ntrnl_mmR;
    dsp_add64(dsp64, (t_object *)x, (t_perfroutine64)mirrorz_perform64, 0, NULL);
}

void mirrorz_dblclick(t_mirrorz *x)
{
    buffer_view(buffer_ref_getobject(x->l_buffer_reference));
}

void mirrorz_assist(t_mirrorz *x, void *b, long m, long a, char *s)
{
    if (m == ASSIST_OUTLET)
    {
        switch (a)
        {
            case 0:    sprintf(s,"Left Out");    break;
            case 1:    sprintf(s,"Right Out");    break;
            case 2:    sprintf(s,"Phase Out");    break;
        }
    }
    else
    {
        switch (a)
        {
            case 0:    sprintf(s,"(signal) Phase/Index Input (other)...");    break;
            case 1:    sprintf(s,"Recording Input Left");    break;
            case 2:    sprintf(s,"Recording Input Right");    break;
            case 3:    sprintf(s,"Play Control");    break;
            case 4:    sprintf(s,"Recording Control");    break;
            case 5:    sprintf(s,"Speed");    break;
        }
    }
}

void *mirrorz_new(t_symbol *s)
{
    long chan = 2;
    t_mirrorz *x = object_alloc(mirrorz_class);
    dsp_setup((t_pxobject *)x, 6);
    outlet_new((t_object *)x, "signal");
    outlet_new((t_object *)x, "signal");
    outlet_new((t_object *)x, "signal");
    mirrorz_set(x, s);
    mirrorz_in1(x,chan);
    x->playC = x->bufvec_pos = 0;
    x->phprev = 0.;
    x->obj.z_misc |= Z_NO_INPLACE;
    return (x);
}


void mirrorz_free(t_mirrorz *x)
{
    dsp_free((t_pxobject *)x);
    object_free(x->l_buffer_reference);
}


t_max_err mirrorz_notify(t_mirrorz *x, t_symbol *s, t_symbol *msg, void *sender, void *data)
{
    return buffer_ref_notify(x->l_buffer_reference, s, msg, sender, data);
}
