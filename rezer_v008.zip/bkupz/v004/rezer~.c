/**
 @file
 rezer~ - sampling/looping object by raja rez
 
 @ingroup    MSP
 */

#include "ext.h"
#include "ext_obex.h"
#include "ext_common.h" // contains CLAMP macro
#include "z_dsp.h"
#include "ext_buffer.h"

// Hermitic Cubic Interp ( courtesy of Alex Harker: http://www.alexanderjharker.co.uk/ )
#define HRMCBINTRP(f, z, a, b, c) ((((0.5*(c - z) + 1.5*(a - b))*f + (z - 2.5*a + b + b - 0.5*c))*f + (0.5*(b - z)))*f + a)

typedef struct _rezer {
    t_pxobject obj;
    t_buffer_ref *bf_ref;
    t_double sr;
    long nchan;
    long fad;
    long cfad;
    long nend;
    long nstart;
    t_bool playC;
    t_bool wrap;
    t_bool change;
    t_bool mode;
    t_double phprev;
    t_double speed;
    t_double fade;
    t_double dpos;
    t_double dcpos;
    t_double virend;
    t_double virstart;
    t_double start;
    t_double end;
} t_rezer;


void rezer_perform64(t_rezer *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampfrms, long flags, void *userparam);
void rezer_dsp64(t_rezer *x, t_object *dsp64, short *count, double samprate, long mxvecsize, long flgs);
void rezer_set(t_rezer *x, t_symbol *s);
void *rezer_new(t_symbol *s);
void rezer_free(t_rezer *x);
t_max_err rezer_notify(t_rezer *x, t_symbol *s, t_symbol *msg, void *sender, void *data);
void rezer_in1(t_rezer *x, long n);
void rezer_fade(t_rezer *x, t_double f);
void rezer_virend(t_rezer *x, t_double nd);
void rezer_virstart(t_rezer *x, t_double strt);
void rezer_assist(t_rezer *x, void *b, long m, long a, char *s);
void rezer_dblclick(t_rezer *x);
static t_class *rezer_class;
                                                              //easing function(fade/crossfade)
static inline double ease_func(double y1, char updwn, double ramp, long fad)
{
    return updwn ? y1*(0.5*(1.0-cos((1.0-(((double)fad)/ramp))*PI))) : y1*(0.5*(1.0-cos((((double)fad)/ramp)*PI)));
}

static inline void interp_index
(t_ptr_int p, t_ptr_int *ndx0,t_ptr_int *ndx1,t_ptr_int *ndx2,t_ptr_int *ndx3, t_ptr_int dr,t_ptr_int frms)
{
    *ndx0 = p - dr; frms -= 1;                              //index-calc for cubic interpolation
    if(*ndx0 < 0) *ndx0 = frms + *ndx0; else if(*ndx0 > frms) *ndx0 = *ndx0 - frms;
    
    *ndx1 = p; *ndx2 = p + dr;
    if(*ndx2 < 0) *ndx2 = frms + *ndx2; else if(*ndx2 > frms) *ndx2 = *ndx2 - frms;
    
    *ndx3 = *ndx2 + dr;
    if(*ndx3 < 0) *ndx3 = frms + *ndx3; else if(*ndx3 > frms) *ndx3 = *ndx3 - frms;
    return;
}

static inline void vreg(t_ptr_int frm, long sampfrms, t_double f, t_double dur, t_double vstr, t_double vnd,
                        t_ptr_int *nstr, t_ptr_int *nnd, t_double *str, t_double *nd, t_bool *wr )
{   //register 'change' in 'virstart/end' messages.. to create 'virtual' buffer boundaries..
    t_double vdur;                                      //..and manage playback bounds in general
    if(vstr<vnd){ *str=vstr*(frm-1); *nd=vnd*(frm-1); }
    else if(vstr>vnd){ *str=vnd*(frm-1); *nd=vstr*(frm-1); }else{ *str=0.; *nd=frm-1; };
    vdur = *nd - *str;
    if(dur>1.) dur=1.; else if(dur<0.) dur=0.; dur = dur * vdur; if(dur<=0.) dur=sampfrms;
    *nstr = (f*vdur) + (*str); *nnd = *nstr + dur;
    if(*nnd>=*nd) *nnd = *str + (*nnd-*nd); else if(*nnd<*str) *nnd = *nd - (*str-*nnd);
    if(*nnd<*nstr) *wr=1; else *wr=0;                                       return;
}

void ext_main(void *r)
{
    t_class *c = class_new("rezer~", (method)rezer_new, (method)rezer_free, sizeof(t_rezer), 0L, A_SYM, A_DEFLONG, 0);
    
    class_addmethod(c, (method)rezer_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)rezer_set, "set", A_SYM, 0);
    class_addmethod(c, (method)rezer_in1, "in1", A_LONG, 0);
    class_addmethod(c, (method)rezer_fade, "fade", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_virend, "virend", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_virstart, "virstart", A_FLOAT, 0);
    class_addmethod(c, (method)rezer_assist, "assist", A_CANT, 0);
    class_addmethod(c, (method)rezer_dblclick, "dblclick", A_CANT, 0);
    class_addmethod(c, (method)rezer_notify, "notify", A_CANT, 0);
    class_dspinit(c); class_register(CLASS_BOX, c); rezer_class = c;
}


void rezer_perform64(t_rezer *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampfrms, long flags, void *userparam)
{   //........inlets: starting 'phase', end, playControl, recordingControl, speed, recording-Inputs-L/R
    //........outlets: left-output, right-output (always stereo) ..phase-output
    t_double    *phase = ins[0];
    t_double    *dr = ins[1];
    t_double    *plyCtl = ins[2];
    t_double    *rcCtl = ins[3];
    t_double    *speed = ins[4];
    t_double    *rInL = ins[5];
    t_double    *rInR = ins[6];
    t_double    *outL = outs[0];
    t_double    *outR = outs[1];
    t_double    *outPh = outs[2];
    t_bool      playC, wrap, change, mode;
    t_ptr_int   n = sampfrms;
    t_ptr_int   chan, frames, nc, fad, cfad, nend, nstart;
    t_ptr_int   indx, indx0, indx1, indx2, indx3, jndx, jndx0, jndx1, jndx2, jndx3, dir;
    t_float     *tab;
    t_double    f, phprev, frac, fric, playc, recc, fade, start, virstart;
    t_double    spd,oL,oR,xL,xR,yL,yR,oP, dur, rcL, rcR, dpos, dcpos, end, virend;
    t_buffer_obj    *buffer = buffer_ref_getobject(x->bf_ref);
    
    tab = buffer_locksamples(buffer);  if (!tab) goto zero;
    frames = buffer_getframecount(buffer);
    nc = buffer_getchannelcount(buffer);
    mode = x->mode;
    chan = MIN(x->nchan, nc);
    start = x->start;
    end = x->end;
    virstart = x->virstart;
    virend = x->virend;
    if(!mode) change = x->change; else change = 1;
    dpos = x->dpos;
    dcpos = x->dcpos;
    playC = x->playC;
    wrap = x->wrap;
    fad = x->fad;
    cfad = x->cfad;
    phprev = x->phprev;
    nstart = x->nstart;
    nend = x->nend;
    spd = x->speed;
    fade = x->fade;
    //...........................................Perform Loop
    while (n--)
    {
        f=*phase++; dur=*dr++; playc=*plyCtl++; recc=*rcCtl++; spd=*speed++; rcL=*rInL++; rcR=*rInR++;
        //....................................Starting/Stopping
        if (playc!=playC)
        {
            fad = fade;
            if (playc == 0) { playC=0; }
            else
            {
                vreg(frames, sampfrms, f, dur, virstart, virend, &nstart, &nend, &start, &end, &wrap);
                change = 0; if(dir>0) dpos = nstart; else dpos = nend; playC = 1;
            }
        }
        //..Once playing: 'phprev!=phas' detects phase change,..'cfad' = crossfade, 'fad' = fadein/out,..
        //............'change' = virstart/end registration(waits for loop-point/phase-change)
        if(playC)
        {
            if (spd>=0) dir = 1; else dir = -1;
            if(!mode)
            {
                if (phprev!=f)
                {
                    vreg(frames, sampfrms, f, dur, virstart, virend, &nstart, &nend, &start, &end, &wrap);
                    change = 0; dcpos = dpos; if(dir>0) dpos = nstart; else dpos = nend; cfad=fade;
                }
            }
        
            indx = trunc(dpos);
            if(dir>0){ frac = dpos-indx; }else if(dir<0){ frac = 1.0-(dpos-indx); } else frac=0.0;
            interp_index(indx,&indx0,&indx1,&indx2,&indx3,dir,frames);
            xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
            xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
            dpos += spd;
            if(!wrap)
            {
                if (dpos>nend)
                {
                    if(change)
                        vreg(frames, sampfrms, f, dur, virstart, virend, &nstart, &nend, &start, &end, &wrap);
                    change=0; dcpos=dpos; dpos = nstart + (dpos - nend); cfad=fade;
                }
                else if (dpos<nstart)
                {
                    if(change)
                        vreg(frames, sampfrms, f, dur, virstart, virend, &nstart, &nend, &start, &end, &wrap);
                    change=0; dcpos=dpos; dpos = nend - (nstart - dpos); cfad=fade;
                }
                if(dpos>=end){ dpos=start+(dpos-end); }else if(dpos<start){ dpos=end-(start-dpos); }
            }
            else
            {
                if ((dpos>nend)&&(dpos<nstart))
                {
                    if(change)
                        vreg(frames, sampfrms, f, dur, virstart, virend, &nstart, &nend, &start, &end, &wrap);
                    change = 0; dcpos = dpos; cfad=fade;
                    if(dir>0) { dpos = nstart+(dpos-nend); }else{ dpos = nend-(nstart-dpos); }
                }
                if(dpos>=end){ dpos=start+(dpos-end); }else if(dpos<start){ dpos=end-(start-dpos); }
            }
        //............................Crossfades(happen at loop-points and phase changes)
            if(cfad>=0)
            {
                jndx = trunc(dcpos);
                if(dir>0){ fric = dcpos-jndx; }else if(dir<0){ fric = 1.0-(dcpos-jndx); } else fric=0.0;
                interp_index(jndx,&jndx0,&jndx1,&jndx2,&jndx3,dir,frames);
                yL = HRMCBINTRP(fric, tab[jndx0*nc], tab[jndx1*nc], tab[jndx2*nc], tab[jndx3*nc]);
                yR = HRMCBINTRP(fric, tab[jndx0*nc+1], tab[jndx1*nc+1], tab[jndx2*nc+1], tab[jndx3*nc+1]);
                oL = ease_func(xL, 1, fade, cfad) + ease_func(yL, 0, fade, cfad);
                oR = ease_func(xR, 1, fade, cfad) + ease_func(yR, 0, fade, cfad);
                dcpos += spd; cfad--; if(dcpos>=frames) dcpos -= frames; else if(dcpos<0) dcpos += frames;
            }   //......................................Fade-In
            else if(fad>=0) { oL = ease_func(xL, 1, fade, fad); oR = ease_func(xR, 1, fade, fad); fad--; }
            else { oL = xL; oR = xR; }  //........<-Regular Playback
        }
        else
        {       //.....................................Fade-Out
            if(fad>=0)
            {
                if (spd>=0) dir = 1; else dir = -1;
                if(dir>0){ indx = dpos+0.5; frac = dpos-indx; }else{ indx = dpos-0.5; frac = indx-dpos; }
                interp_index(indx,&indx0,&indx1,&indx2,&indx3,dir,frames);
                xL = HRMCBINTRP(frac, tab[indx0*nc], tab[indx1*nc], tab[indx2*nc], tab[indx3*nc]);
                xR = HRMCBINTRP(frac, tab[indx0*nc+1], tab[indx1*nc+1], tab[indx2*nc+1], tab[indx3*nc+1]);
                dpos += spd; if(dcpos>=frames) dcpos -= frames; else if(dcpos<0) dcpos += frames;
                oL = ease_func(xL, 0, fade, fad); oR = ease_func(xR, 0, fade, fad);     fad--;
            }else{ dpos = oL = oR = 0.; }  //........<-Everything Off
        }
        oP = dpos/(double)frames; //.......<-Sample-Index Converted to Phase
        *outL++ = oL; *outR++ = oR; *outPh++ = oP; phprev = f; //.....<-Output and Phase-history
    }
    
    x->phprev = phprev;
    x->nend = nend;
    x->nstart = nstart;
    x->start = start;
    x->end = end;
    x->playC = playC;
    x->wrap = wrap;
    x->change = change;
    x->fad = fad;
    x->cfad = cfad;
    x->dpos = dpos;
    x->dcpos = dcpos;
    x->speed = spd;
    buffer_unlocksamples(buffer);
    return;
zero:
    while (n--) { *outL++ = 0.0; *outR++ = 0.0; *outPh++ = 0.0; }
}

void rezer_set(t_rezer *x, t_symbol *s)
{
    t_buffer_obj    *buffer;
    if (!x->bf_ref) x->bf_ref = buffer_ref_new((t_object *)x, s); else buffer_ref_set(x->bf_ref, s);
    buffer = buffer_ref_getobject(x->bf_ref); buffer_locksamples(buffer);
    x->nend = (buffer_getframecount(buffer))-1; buffer_unlocksamples(buffer);
}

void rezer_in1(t_rezer *x, long n) { x->mode = n; }

void rezer_fade(t_rezer *x, t_double f) { x->fade = f; }

void rezer_virend(t_rezer *x, t_double nd)
{ nd = (nd > 1.) ? 1. : nd; nd = (nd <= 0.) ? 0.0001 : nd; x->virend = nd; x->change = 1; }

void rezer_virstart(t_rezer *x, t_double strt)
{ strt = (strt > 1.) ? 1. : strt; strt = (strt <= 0.) ? 0. : strt; x->virstart = strt; x->change = 1; }

void rezer_dsp64(t_rezer *x, t_object *dsp64, short *count, double samprate, long mxvecsize, long flgs)
{ x->sr = samprate; dsp_add64(dsp64, (t_object *)x, (t_perfroutine64)rezer_perform64, 0, NULL); }

void rezer_dblclick(t_rezer *x) { buffer_view(buffer_ref_getobject(x->bf_ref)); }

void rezer_assist(t_rezer *x, void *b, long m, long a, char *s)
{
    if (m == ASSIST_OUTLET) {switch (a)
        {
            case 0:    sprintf(s,"Left Out");    break;
            case 1:    sprintf(s,"Right Out");    break;
            case 2:    sprintf(s,"Phase Out");    break;
        }       }
    else {switch (a)
        {
            case 0:    sprintf(s,"(signal) Phase/Index Input (other)...");    break;
            case 1:    sprintf(s,"Ending Phase");    break;
            case 2:    sprintf(s,"Play Control");    break;
            case 3:    sprintf(s,"Recording Control");    break;
            case 4:    sprintf(s,"Speed");    break;
            case 5:    sprintf(s,"Recording Input Left");    break;
            case 6:    sprintf(s,"Recording Input Right");    break;
        }       }
}

void *rezer_new(t_symbol *s)
{
    long chan = 2; t_rezer *x = object_alloc(rezer_class); dsp_setup((t_pxobject *)x, 7);
    outlet_new((t_object *)x, "signal"); outlet_new((t_object *)x, "signal");
    outlet_new((t_object *)x, "signal"); rezer_set(x, s); x->nchan = chan;
    x->mode = x->change = x->fad = x->cfad = x->wrap = x->playC = 0;
    x->fade = 512.; x->virstart = x->dpos = x->dcpos = x->phprev = 0.;
    x->virend = x->speed = 1.; x->obj.z_misc |= Z_NO_INPLACE; post("v.004"); return (x);
}

void rezer_free(t_rezer *x) { dsp_free((t_pxobject *)x); object_free(x->bf_ref); }

t_max_err rezer_notify(t_rezer *x, t_symbol *s, t_symbol *msg, void *sender, void *data)
{ return buffer_ref_notify(x->bf_ref, s, msg, sender, data); }
